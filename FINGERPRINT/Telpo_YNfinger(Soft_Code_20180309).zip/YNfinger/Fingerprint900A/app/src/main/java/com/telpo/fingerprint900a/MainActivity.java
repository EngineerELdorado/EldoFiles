package com.telpo.fingerprint900a;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;


import com.telpo.fingerprint900a.R;
import com.telpo.fingerprint900a.util.DataProcessUtil;
import com.telpo.fingerprint900a.util.RawToBitMap;
import com.telpo.usb.finger.Finger;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends Activity {
	ImageView fp_image;
	Button init,clear_all_tmpl,enroll1 ,enroll2,enroll3,identify,get_img,read_template,write_template,store_ram,
			read_ram, convert_ISO_to_FPT,convert_FPT_to_ISO,verify_ISO_tmpl,update_tmpl,generate_ram,convert_IMG_to_WSQ,convert_WSQ_to_IMG;

	ProgressDialog progressDialog;
	int rets , bytelength;

	byte[] ISOTmpl = new byte[810];
	byte[] FPTAddr;
	byte[] img_data = new byte[250 * 360];
	int[] TMPL_No = new int[1];
	int[] pnDuplNo = new int[1];
	byte[] wsq_data = new byte[258*358];

	byte[] ISOAddrs = new byte[820];
	int[] isoresult = new int[1];

	String tmplstr = "9C7B63ECA1C1C011C6FACAA9FCD448DF587DC637D3550CC74186A2EBDB91D9DFA58365E057E6265895F1F9C6B5C38914ABF4B096016035255F730F014395051D9537AE792E60AA61A4E34729B5A65EE20B02A0DFF6C03429C7DBE74C79AF59F12C231BA04F0C72AF37198C8DB689FDCEA36A515A6E8BA350CAAEC2F74EC75C44326237822DDE7C49645CF2D8969834AD5212855ABD13AB6A1391EACA0A3805C0C0B4B35AEFDFF079733FA9F462CDCB73CF5249D6C39682095F2E5EB10753E0A4A112B1CE8A2E8860E9E207B34D35819F6C4D91C30775E6FC213874A414556B280B554AD4F7E53048A5490AAEE971311CB09A0083D9BF38E10904B9BC5A05E0B9D44B71D44C91271D4EF71CE17B39815B555B83B7FFE1271098191A6BDDDCDBFCD42EEDFBE353D2F0F0C2E0BCE3E773D2956CEAEDF1E4A24E668DBD76030AAA9E8643C45D36EA8DA41C7B0E78B50E9FB949AFCDB8DCCCA9C1A48BA82607504C9E00DD243EA0A2205D1BE966FFAE65DF7DABF99B0B38B63CCA9E3BA4CBDF90FAED78A7B657DA4DD0F69FC9BEB170F99B5AD8D3205596ADB55FA10F9B27A95F3FC645D7BE1EDCA924603C18BF68933E9A2B3B497C946BCB9DF634E6FABF790B573392183C2FB240E3C8E057DA9FA2529924394CADD567C02444FA947249096A72F99CCF21AE6796E07C5E6FD85279756DED42513A8C5468909CC6C6A8091036EBA5";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		fp_image = (ImageView) findViewById(R.id.fp_image);
		//upgradeRootPermission(getPackageCodePath());

		init = (Button) findViewById(R.id.init);
		clear_all_tmpl = (Button) findViewById(R.id.clear_all_tmpl);
		enroll1 = (Button) findViewById(R.id.enroll1);
		enroll2 = (Button) findViewById(R.id.enroll2);
		enroll3 = (Button) findViewById(R.id.enroll3);
		identify = (Button) findViewById(R.id.identify);
		get_img = (Button) findViewById(R.id.get_img);
		read_template = (Button) findViewById(R.id.read_template);
		write_template = (Button) findViewById(R.id.write_template);
		store_ram = (Button) findViewById(R.id.store_ram);
		read_ram = (Button) findViewById(R.id.read_ram);
		convert_ISO_to_FPT = (Button) findViewById(R.id.convert_ISO_to_FPT);
		convert_FPT_to_ISO = (Button) findViewById(R.id.convert_FPT_to_ISO);
		verify_ISO_tmpl = (Button) findViewById(R.id.verify_ISO_tmpl);
		update_tmpl = (Button) findViewById(R.id.update_tmpl);
		generate_ram = (Button) findViewById(R.id.generate_ram);
		convert_IMG_to_WSQ = (Button) findViewById(R.id.convert_IMG_to_WSQ);
		convert_WSQ_to_IMG = (Button) findViewById(R.id.convert_WSQ_to_IMG);

		copyfile(Environment.getExternalStorageDirectory().toString()+"/wsq_img.wsq","wsq_img.wsq");
		//copyfile(Environment.getExternalStorageDirectory().toString()+"/jun(ISO)","jun(ISO)");

	}


	public void onClick(View view) {
		int ret, en_Step;
		switch (view.getId()) {

			case R.id.init:
				byte[] init = new byte[250 * 360];
				rets = Finger.initialize(init);
				if (rets == 0) {
					Toast.makeText(this, "Initialize success: "+ String.format("0x%02x", rets), Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(this, "Initialize failed: " + String.format("0x%02x", rets), Toast.LENGTH_SHORT).show();
				}
				break;
			case R.id.clear_all_tmpl:
				ret = Finger.clear_alltemplate();
				if (ret == 0) {
					Toast.makeText(this, "clear_all_tmpl" + String.format("0x%02x", ret) + "Clear success", Toast.LENGTH_SHORT).show();

				} else {
					Toast.makeText(this, "clear_all_tmpl" + String.format("0x%02x", ret) + "Clear failed", Toast.LENGTH_SHORT).show();

				}

				break;
			case R.id.enroll1:
				ret = Finger.get_empty_id(TMPL_No);
				if (ret == 0) {
					en_Step = 0;
					ret = Finger.enroll(en_Step, TMPL_No[0], pnDuplNo);
					if (ret == 0) {
						ret = Finger.get_image(img_data);
						if (ret == 0) {
							en_Step = 1;
							ret = Finger.enroll(en_Step, TMPL_No[0], pnDuplNo);
							if (ret == 0) {
								Toast.makeText(this, "enroll:" + String.format("0x%02x", ret) + "enroll success", Toast.LENGTH_SHORT).show();
								return;
							}
						}
					}
				}
				Toast.makeText(this, "get_empty_id" + String.format("0x%02x", ret) + ",enroll failed", Toast.LENGTH_SHORT).show();

				break;
			case R.id.enroll2:
				ret = Finger.get_image(img_data);
				if (ret == 0) {
					en_Step = 2;
					ret = Finger.enroll(en_Step, TMPL_No[0], pnDuplNo);
					if (ret == 0) {
						Toast.makeText(this, "enroll:" + String.format("0x%02x", ret) + "enroll success", Toast.LENGTH_SHORT).show();
						return;
					}
				}
				Toast.makeText(this, "get_image:" + String.format("0x%02x", ret) + "enroll failed", Toast.LENGTH_SHORT).show();
				break;
			case R.id.enroll3:
				ret = Finger.get_image(img_data);
				if (ret == 0) {
					en_Step = 3;
					ret = Finger.enroll(en_Step, TMPL_No[0], pnDuplNo);
					if (ret == 0) {
						en_Step = 4;
						pnDuplNo[0] = 3;
						ret = Finger.enroll(en_Step, TMPL_No[0], pnDuplNo);
						if (ret == 0) {
							Toast.makeText(this, "enroll:" + String.format("0x%02x", ret) + "nroll success", Toast.LENGTH_SHORT).show();
							return;
						}
					}
				}
				Toast.makeText(this, String.format("0x%02x", ret) + "enroll failed", Toast.LENGTH_SHORT).show();

				break;
			case R.id.identify:
				int[] TMPL_id = new int[1];
				ret = Finger.get_image(img_data);
				if (ret == 0) {
					ret = Finger.identify(TMPL_id);
					if (ret == 0) {
						Toast.makeText(this, String.format("0x%02x", ret) + "success，ID:" + TMPL_id[0], Toast.LENGTH_SHORT).show();
						return;
					}
				}
				Toast.makeText(this, String.format("0x%02x", ret) + "failed", Toast.LENGTH_SHORT).show();

				break;
			case R.id.get_img:
				ret = Finger.get_image(img_data);
				if (ret == 0) {
					Bitmap bmp = RawToBitMap.convert8bit(img_data, 242, 266);
					saveImage(bmp,System.currentTimeMillis()+".jpg");
					if (bmp != null) {
						fp_image.setImageBitmap(bmp);
					}
					return;
				}
				Toast.makeText(this, String.format("0x%02x", ret), Toast.LENGTH_SHORT).show();

				break;
			case R.id.read_template:
				byte[] ppBff = new byte[512];
				int fingerNoId = 1;
				ret = Finger.read_template(fingerNoId, ppBff);
				if (ret == 0) {
					FPTAddr =ppBff;
					Log.e("read_template", DataProcessUtil.bytesToHexString(ppBff));
					Toast.makeText(this, String.format("0x%02x", ret) + "success:"+DataProcessUtil.bytesToHexString(ppBff)
							, Toast.LENGTH_SHORT).show();
					return;
				}
				Toast.makeText(this, String.format("0x%02x", ret)+ "fail", Toast.LENGTH_SHORT).show();

				break;
			case R.id.write_template:
				byte[] tmpldata = DataProcessUtil.hexStringToByte(tmplstr);
				int[] dup_ID = new int[1];
				int fingerId = 1;
				ret = Finger.write_template(fingerId, tmpldata, dup_ID);
				if (ret == 0) {
					Toast.makeText(this, String.format("0x%02x", ret) + "success,ID:"+dup_ID[0], Toast.LENGTH_SHORT).show();
					return;
				}
				Toast.makeText(this, String.format("0x%02x", ret) + "fail", Toast.LENGTH_SHORT).show();

				break;
			case R.id.store_ram:
				ret = Finger.get_image(img_data);
				Log.e("store_ram", DataProcessUtil.bytesToHexString(img_data));
				int RamAddr = 0;
				if (ret == 0) {
					Bitmap bmp = RawToBitMap.convert8bit(img_data, 242, 266);
					saveImage(bmp,System.currentTimeMillis()+".jpg");
					ret = Finger.store_ram(RamAddr,0);
					if (ret == 0) {
						Toast.makeText(this, String.format("0x%02x", ret) + "success", Toast.LENGTH_SHORT).show();
						return;
					}
				}
				Toast.makeText(this, String.format("0x%02x", ret) + "failed", Toast.LENGTH_SHORT).show();
				break;
			case R.id.read_ram:
				byte[] p_nTmplAddr = new byte[512];
				int RamAddrs = 0;
				ret = Finger.read_ram(RamAddrs, p_nTmplAddr);
				if (ret == 0) {
					FPTAddr = p_nTmplAddr;
					saveFile(FPTAddr,"unknow");
					Log.e("read_ram", DataProcessUtil.bytesToHexString(p_nTmplAddr));
					Toast.makeText(this, String.format("0x%02x", ret)+ " Success:" + DataProcessUtil.bytesToHexString(p_nTmplAddr), Toast.LENGTH_SHORT).show();
					return;
				}
				Toast.makeText(this, String.format("0x%02x", ret)+"fail" ,Toast.LENGTH_SHORT).show();
				break;
			case R.id.convert_ISO_to_FPT:
				byte[] fptAddrs = new byte[512];

				try{
					byte[] ISO2005 = readFile("iso2005");//fingera
					int length = ISO2005.length;

					Log.e("convert_ISO_to_FPT-", "length:"+length+" \nisoaddr:"+DataProcessUtil.bytesToHexString(ISO2005));
					ret = Finger.convert_ISO_to_FPT(ISO2005, fptAddrs);
					if (ret == 0) {
						saveFile(fptAddrs,"iso_to_fpt");
						Log.e("convert_ISO_to_FPT,fpt:", DataProcessUtil.bytesToHexString(fptAddrs));
						Toast.makeText(this, String.format("0x%02x", ret) +" ,Success:" + DataProcessUtil.bytesToHexString(fptAddrs), Toast.LENGTH_SHORT).show();
						return;
					}
					Toast.makeText(this, String.format("0x%02x", ret)+"fail" ,Toast.LENGTH_SHORT).show();
				}catch (Exception e){

				}
				break;
			case R.id.convert_FPT_to_ISO:
				byte[] ISOAddr = new byte[890];
				byte[] fpt = {
						(byte) 0xCF, (byte)0xF1, (byte)0x8C, 0x2D, (byte)0x8E, 0x4F, (byte)0xA1, (byte)0xC2, 0x69, 0x70, 0x68, (byte)0xF0, (byte)0x9A, (byte)0x84, (byte)0x98, 0x26,
						(byte)0x9E, 0x39, 0x6D, (byte)0xFE, 0x75, 0x04, 0x58, 0x78, 0x57, 0x05, 0x4C, (byte)0xCA, (byte)0xC9, (byte)0xF9, (byte)0xB9, 0x17,
						0x45, 0x61, (byte)0xBE, (byte)0xD5, (byte)0xD3, (byte)0x82, (byte)0xFA,(byte) 0x87, (byte)0xAC,(byte) 0x88, (byte)0xDF, (byte)0x97, (byte)0x8E, 0x68, (byte)0x96, 0x07,
						(byte)0xCC, (byte)0xA8, 0x30, (byte)0xCD, (byte)0xF2, 0x22, 0x4D, 0x5F, (byte)0xA5, 0x51, (byte)0xAF, 0x1E, 0x46, 0x75, 0x7A, (byte)0xA1,
						(byte)0xDD, (byte)0xFB, (byte)0xE3, 0x06, (byte)0x8A, 0x23, (byte)0xA8, 0x59, (byte)0xFF, 0x04, (byte)0xDB, (byte)0x83, 0x64, (byte)0x8E, (byte)0x9F, (byte)0xF9,
						(byte)0xD8, 0x71, 0x01, (byte)0x97, (byte)0xD5, (byte)0xC0, (byte)0x9D, 0x2E, 0x4E, 0x6A, (byte)0xDD, (byte)0x83, (byte)0xBC, 0x52, (byte)0xC3, 0x06,
						(byte)0xCB, 0x0E, 0x60, (byte)0xCE, 0x77, 0x62, (byte)0xAF, (byte)0xAA, (byte)0x9A, 0x2E, (byte)0x84, (byte)0xFC, (byte)0xA2, 0x27, 0x46, (byte)0xE3,
						0x64, 0x2E, 0x59, (byte)0xF8, (byte)0xB7, (byte)0xAB, (byte)0x8F, 0x4E, (byte)0xC8, (byte)0xCC, (byte)0xBA, (byte)0xD8, 0x34, 0x47, (byte)0xDA, (byte)0xD3,
						(byte)0xA6, (byte)0xA6, 0x68, (byte)0xDB, (byte)0xD5, 0x28, 0x0F, 0x78, (byte)0xA4, 0x4E, (byte)0xBE, 0x29, 0x26, 0x23, 0x5A, 0x7E,
						0x21, (byte)0xF3, (byte)0xDD, (byte)0xC0, 0x27, (byte)0xF5, (byte)0xB1, (byte)0x82, 0x54, (byte)0xC9, 0x7F, (byte)0xCD, 0x1E, 0x62, 0x13, 0x3E,
						(byte)0xF6, 0x10, (byte)0xCF, (byte)0x9B, (byte)0xC2, 0x42, (byte)0xEF, 0x4A, 0x37, 0x56, 0x2D, (byte)0xBD, (byte)0xF8, (byte)0xF6, (byte)0xD0, 0x09,
						(byte)0x81, 0x1F, (byte)0x9C, 0x5F, 0x71, 0x4B, 0x6C, 0x4E, 0x1A, 0x1D, (byte)0xD7, (byte)0xB2, 0x2A, (byte)0xD3, 0x39, (byte)0xB2,
						(byte)0xDA, (byte)0xBE, (byte)0xF5, (byte)0xA2, 0x47, 0x6C, 0x3B, (byte)0xA6, 0x1A, (byte)0x90, 0x48, (byte)0xFE, (byte)0xAC, (byte)0xA7, 0x6D, 0x4F,
						0x4F, (byte)0xE6, (byte)0xCA, 0x3B, 0x32, (byte)0xB1, (byte)0xCA, 0x5B, (byte)0xA5, 0x6F, (byte)0xFB, (byte)0xA8, (byte)0xA5, (byte)0x86, (byte)0x92, (byte)0xB2,
						0x5D, 0x20, 0x31, 0x61, 0x0A, 0x52, (byte)0xEB, 0x50, 0x10, (byte)0xBE, 0x10, 0x66, (byte)0xF6, (byte)0x86, (byte)0xF1, (byte)0xE9,
						0x5F, 0x10, (byte)0xE6, 0x7E, (byte)0xBB, 0x7B, 0x7E, (byte)0x97, (byte)0xED, (byte)0x81, 0x6A, 0x1E, (byte)0xEB, (byte)0x89, 0x4F, 0x01,
						0x57, (byte)0xBB, 0x1C, (byte)0x9A, 0x7E, 0x70, (byte)0x90, 0x21, (byte)0xBA, 0x73, (byte)0xD4, 0x25, (byte)0x84, 0x0A, 0x1D, (byte)0xC2,
						0x05, (byte)0xD7, (byte)0xBC, 0x47, (byte)0xE2, 0x6E, 0x7F, 0x53, (byte)0xB9, 0x32, 0x5D, 0x3E, 0x16, (byte)0xC0, (byte)0xED, (byte)0xDC,
						(byte)0xC1, (byte)0xA8, 0x15, (byte)0xA7, 0x4A, (byte)0xBC, (byte)0xD1, (byte)0x90, 0x0E, 0x17, (byte)0xDD, 0x55, 0x46, 0x57, 0x3C, 0x67,
						(byte)0x87, (byte)0xB3, (byte)0x8E, 0x53, 0x74, 0x3B, (byte)0xDF, 0x24, 0x4D, (byte)0x8E, 0x41, 0x34, (byte)0x83, (byte)0xA0, (byte)0xEB, 0x5F,
						(byte)0xEB, (byte)0xDF, 0x0B, (byte)0xC6, (byte)0xBD, 0x69, (byte)0x95, (byte)0x9B, 0x3E, (byte)0xD0, 0x5A, (byte)0x8E, (byte)0xD8, (byte)0x86, 0x0C, (byte)0xF8,
						(byte)0xF1, (byte)0xBB, (byte)0xCE, (byte)0x9F, (byte)0x83, 0x36, (byte)0xB6, (byte)0xF6, (byte)0x8B, 0x22, 0x72, (byte)0xB1, 0x45, (byte)0x89, 0x17, 0x10,
						0x5F, 0x1B, (byte)0xAF, (byte)0xA3, (byte)0x90, 0x34, 0x61, (byte)0xFD, (byte)0xFF, (byte)0x9C, (byte)0x9F, (byte)0x9C, (byte)0xA5, 0x23, (byte)0x92, 0x3C,
						0x1F, (byte)0xC2, (byte)0xED, (byte)0xEF, (byte)0xF7, (byte)0xCE, 0x67, (byte)0xB5, (byte)0xE6, 0x7E, 0x05, 0x5C, 0x74, (byte)0xFD, (byte)0xCA, 0x38,
						(byte)0xD9, 0x16, (byte)0xC7, (byte)0xF0, 0x29, 0x38, (byte)0xF5, (byte)0x82, (byte)0xC7, (byte)0xFC, (byte)0xB2, 0x34, 0x69, 0x32, 0x44, 0x70,
						0x1B, (byte)0x99, 0x37, (byte)0x9A, 0x33, (byte)0xE6, (byte)0xC3, 0x5E, 0x05, 0x45, 0x4E, 0x2C, (byte)0xC0, (byte)0x8A, 0x26, (byte)0x83,
						0x6A, (byte)0x81, 0x25, (byte)0xDC, (byte)0xFC, (byte)0xC5, (byte)0xCA, 0x03, (byte)0xE3, (byte)0xAB, 0x0C, 0x35, (byte)0xBB, 0x55, 0x7C, 0x63,
						0x54, (byte)0xD9, (byte)0x86, 0x3C, 0x7B, 0x2E, (byte)0xBF, (byte)0xFF, 0x3E, 0x0B, (byte)0x99, (byte)0x89, 0x4A, (byte)0x9D, (byte)0x9B, (byte)0xBD,
						(byte)0xA5, 0x6E, 0x22, 0x41, 0x5D, (byte)0xFA, (byte)0xE5, (byte)0xEB, (byte)0xFA, (byte)0xEF, (byte)0xBA, (byte)0xD6, (byte)0xCA, 0x33, (byte)0xD6, 0x58,
						(byte)0xD1, (byte)0xD1, (byte)0xE9, 0x7B, (byte)0xF6, (byte)0x86, (byte)0xAA, (byte)0xDB, 0x38, 0x28, 0x59, 0x0B, (byte)0x9B, 0x5D, (byte)0xFB, (byte)0x8D,
						0x49, 0x66, 0x49, (byte)0x9E, (byte)0xF6, 0x5A, 0x1E, (byte)0xED, 0x17, (byte)0xC5, 0x5D, (byte)0xA2, (byte)0xE7, 0x51, 0x7C, 0x1A,
						0x03, 0x45, 0x0C, (byte)0x91, (byte)0xE9, (byte)0x91, (byte)0xEF, 0x73, 0x7B, (byte)0x96, (byte)0xD1, 0x1F, 0x4C, (byte)0x83, (byte)0xFE, (byte)0xDA};

				try{
					int[] length = new int[1];
					ret = Finger.convert_FPT_to_ISO(fpt , ISOAddr ,length);
					if (ret == 0) {
						//ISOTmpl = ISOAddr;
						saveFile(ISOAddr,"fpt_to_iso");
						Log.e("convert_FPT_to_ISO", DataProcessUtil.bytesToHexString(ISOAddr));
						Toast.makeText(this, String.format("0x%02x", ret) +",length: "+ length[0] + " Success:"+ DataProcessUtil.bytesToHexString(ISOAddr)
								, Toast.LENGTH_SHORT).show();
						return;
					}
					Toast.makeText(this, String.format("0x%02x", ret)+"fail" ,Toast.LENGTH_SHORT).show();
				}catch (Exception e){

				}

				break;
			case R.id.verify_ISO_tmpl:
				try{

					byte[] ISO1 = readFile("fingera1");//fingera1,jun(ISO)
					byte[] ISO2 = readFile("fingera2");

					Log.e("verify_ISO_tmpl", "ISO1: "+DataProcessUtil.bytesToHexString(ISO1)+"\nISO2: "+DataProcessUtil.bytesToHexString(ISO2));

					ret = Finger.verify_ISO_tmpl(ISO1, ISO2,isoresult); //ISOTmpl

					if (ret == 0) {
						Toast.makeText(this, String.format("0x%02x", ret)+ " , verify success" , Toast.LENGTH_SHORT).show();
						return;
					}
					Toast.makeText(this, String.format("0x%02x", ret)+" , verify fail" ,Toast.LENGTH_SHORT).show();
				}catch (Exception e){
					Log.e("verify_ISO_tmpl", "ISO2: "+DataProcessUtil.bytesToHexString(ISOTmpl));
				}
				break;
			case R.id.update_tmpl:
				//It must be executed immediately after identify command, otherwise it will not be valid
				int[] id = new int[1];
				int[] result =new int[1];
				ret = Finger.get_image(img_data);
				if (ret == 0) {
					ret = Finger.identify(id);
					if (ret == 0) {
						ret = Finger.update_tmpl(result);
						if (ret == 0) {
							if(result[0] == 1){
								Toast.makeText(this, String.format("0x%02x", ret) + "update success", Toast.LENGTH_SHORT).show();
								return;
							}else if(result[0] == 0){
								Toast.makeText(this, String.format("0x%02x", ret) + "update fail", Toast.LENGTH_SHORT).show();
								return;
							}

						}
					}
				}
				Toast.makeText(this, String.format("0x%02x", ret) + "failed: It must be executed immediately after identify command, otherwise it will not be valid", Toast.LENGTH_LONG).show();
				break;
			case R.id.generate_ram:
//				int ramaddr = 2;
//				int count =2;
//				ret = Finger.generate_ram(ramaddr, count);
//				if (ret == 0) {
//					Toast.makeText(this, String.format("0x%02x", ret) + "success:", Toast.LENGTH_SHORT).show();
//					return;
//				}
//				Toast.makeText(this, String.format("0x%02x", ret)+ "fail", Toast.LENGTH_SHORT).show();
				break;
			case R.id.convert_IMG_to_WSQ:
//				byte[] img = new byte[256 * 360];
//				byte[] wsq_datas = new byte[20000];
//
////				byte[] len=new byte[4];
////				len[0]=(256&0xff00)>>8;
////				len[1]=256&0x00ff;
////				len[2]=(360&0xff00)>>8;
////				len[3]=360&0x00ff;
////				int length=(int)(len[0]<<24|len[1]|len[2]|len[3]);
//
//				ret = Finger.get_image(img);
//				if (ret == 0) {
//				   //img = readFile("img256_360.raw");
//					ret = Finger.convert_IMG_to_WSQ(img, wsq_datas, img.length);
//					if (ret >= 0) {
//						byte[] wsq = new byte[ret];
//						for(int i=0;i<ret;i++){
//							wsq[i] = wsq_datas[i];
//						}
//						saveFile(wsq,"test.wsq");
//
////						String encodedString = Base64.encodeToString(wsq_datas, Base64.DEFAULT);
////						byte[] decodeBytes = Base64.decode(encodedString.getBytes(), Base64.DEFAULT);
////						//saveFile(decodeBytes,"base64");
////						Log.e("base64加密", wsq_datas.length+"-"+encodedString );
////						Log.e("base64解密", decodeBytes.length+"-"+DataProcessUtil.bytesToHexString(decodeBytes));
//						Log.e("IMG_to_WSQ", ret+"-"+wsq_datas.length+"-"+DataProcessUtil.bytesToHexString(wsq_datas));
//						Toast.makeText(this, ret + ", img to wsq Success:" + DataProcessUtil.bytesToHexString(wsq_datas)
//								, Toast.LENGTH_LONG).show();
//						return;
//					}
//				}
//				Toast.makeText(this, String.format("0x%02x", ret)+" fail" ,Toast.LENGTH_SHORT).show();

				break;
			case R.id.convert_WSQ_to_IMG:
//				byte[] img_datas = new byte[256 * 360];
//
//				//wsq_data = readFile("wsq_img.wsq");
//				wsq_data = readFile("test.wsq");
//				Log.e("wsq数据",wsq_data.length+"-"+DataProcessUtil.bytesToHexString(wsq_data));
//
//				ret = Finger.convert_WSQ_to_IMG(img_datas, wsq_data, wsq_data.length);
//				if (ret == 0) {
//					saveFile(img_datas,"wsqtoimg.raw");
//					Bitmap b =  RawToBitMap.convert8bit(img_datas, 242, 266);
//					saveImage(b,"img.png");
//					fp_image.setImageBitmap(b);
//
//					Log.e("convert_WSQ_to_IMG", DataProcessUtil.bytesToHexString(img_datas));
//					Toast.makeText(this, String.format("0x%02x", ret) + ",wsq to img Success:" + DataProcessUtil.bytesToHexString(img_datas), Toast.LENGTH_LONG).show();
//					return;
//				}
//
//				Toast.makeText(this, String.format("0x%02x", ret)+"fail" ,Toast.LENGTH_SHORT).show();
				break;
			case R.id.get_iso2005:
				byte[] ISOAddrs = new byte[890];
				int[] length = new int[1];
				byte[] quality = new byte[1];
				try{
					ret = Finger.get_image(img_data);
					if (ret == 0) {
						ret = Finger.get_ISO2005(ISOAddrs, length, quality);
						if (ret == 0) {
							saveFile(ISOAddrs,"iso2005");
							Log.e("get_ISO2005", length[0]+"-"+quality[0]+"-"+DataProcessUtil.bytesToHexString(ISOAddrs));
							Toast.makeText(this, String.format("0x%02x", ret) + ",length: " + length[0] + " Success:" + DataProcessUtil.bytesToHexString(ISOAddrs)
									, Toast.LENGTH_SHORT).show();
							return;
						}
					}
					Toast.makeText(this, String.format("0x%02x", ret)+"fail" ,Toast.LENGTH_SHORT).show();
				}catch (Exception e){

				}
				break;
		}
	}

	public Bitmap yuvToBitmap(byte[] data, int width, int height) {
		int frameSize = width * height;
		int[] rgba = new int[frameSize];
		for (int i = 0; i < height; i++)
			for (int j = 0; j < width; j++) {
				int y = (0xff & ((int) data[i * width + j]));
				int u = (0xff & ((int) data[frameSize + (i >> 1) * width + (j & ~1) + 0]));
				int v = (0xff & ((int) data[frameSize + (i >> 1) * width + (j & ~1) + 1]));
				y = y < 16 ? 16 : y;
				int r = Math.round(1.164f * (y - 16) + 1.596f * (v - 128));
				int g = Math.round(1.164f * (y - 16) - 0.813f * (v - 128) - 0.391f * (u - 128));
				int b = Math.round(1.164f * (y - 16) + 2.018f * (u - 128));
				r = r < 0 ? 0 : (r > 255 ? 255 : r);
				g = g < 0 ? 0 : (g > 255 ? 255 : g);
				b = b < 0 ? 0 : (b > 255 ? 255 : b);
				rgba[i * width + j] = 0xff000000 + (b << 16) + (g << 8) + r;
			}
		Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
		bmp.setPixels(rgba, 0 , width, 0, 0, width, height);
		return bmp;
	}

	/**
	 * char[]-to-byte[]
	 */
	private byte[] chartobyte(char[] c1,char[] c2){
		byte[] bs1 = new byte[c1.length];//定义一个长度与需要转换的char数组相同的byte数组
		for(int i = 0; i < c1.length; i++) {//循环将char数组的每一个元素转换为byte并存在上面定义的byte数组中
			byte b = (byte) c1[i];//将每一个char转换成byte
			bs1[i] = b;//保存到数组中
		}
		byte[] bs2 = new byte[c2.length];
		for(int i = 0; i < c2.length; i++) {
			byte b = (byte) c2[i];
			bs2[i] = b;//保存到数组中
		}

		byte[] wsq = new byte[bs1.length+bs2.length];
		System.arraycopy(bs1,0,wsq,0,bs1.length);
		System.arraycopy(bs2,0,wsq,bs1.length,bs2.length);
		return wsq;
	}


	/**
	 * InputStream2ByteArray
	 */
	private byte[] InputStream2ByteArray(String filename) throws IOException {

		InputStream in = getApplicationContext().getAssets().open(filename);
		byte[] data = toByteArray(in);
		in.close();

		return data;
	}

	/**
	 * toByteArray
	 */
	private byte[] toByteArray(InputStream in) throws IOException {

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		byte[] buffer = new byte[810];
		int n = 0;
		while ((n = in.read(buffer)) != -1) {
			out.write(buffer, 0, n);
		}
		return out.toByteArray();
	}

	/**
	 * 从字节数组中获取字节长度
	 *
	 * @param b
	 * @return
	 */
	public int getLenFromByte(byte[] b) {
		InputStream in = null;
		in = new ByteArrayInputStream(b);
		int len = 0;
		try {
			len = in.available();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return len;
	}

	/**
	 * 保存byte[]到文件根目录
	 */
	private int saveFile(byte[] out, String fileName){
		try {
			File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + fileName);
			if(file.exists()){
				file.delete();
			}
			FileOutputStream fileOutputStream = new FileOutputStream(file);
			BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
			bufferedOutputStream.write(out);
			bufferedOutputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
			return -1;
		}
		return 0;
	}

	/**
	 * 从文件读取byte[]
	 */
	private byte[] readFile(String fileName){
		byte[] buffer = null;
		try {
			File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + fileName);
			if(!(file.exists())){
				return null;
			}
			FileInputStream fileInputStream = new FileInputStream(file);
			buffer = new byte[fileInputStream.available()];
			fileInputStream.read(buffer);
			fileInputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return buffer;
	}


	/**
	 * 显示加载对话框
	 *
	 * @param message
	 */
	public void showLoadingDialog(String message) {
		if (progressDialog == null) {
			progressDialog = new ProgressDialog(this);
			progressDialog.setCancelable(false);
		}
		progressDialog.setMessage(message);
		progressDialog.show();

	}

	/**
	 * 隐藏加载对话框
	 */
	public void dismissLoadingDialog() {
		if (progressDialog != null && progressDialog.isShowing()) {
			progressDialog.dismiss();
		}
	}

	/**
	 * 保存bmp到固定名字的文件夹路径
	 */
	private  void saveImage(Bitmap bmp,String name) {
		File appDir = new File(Environment.getExternalStorageDirectory(), "Boohee");
		if (!appDir.exists()) {
			appDir.mkdir();
		}
		String fileName = name;
		File file = new File(appDir, fileName);
		try {
			FileOutputStream fos = new FileOutputStream(file);
			bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
			fos.flush();
			fos.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Bitmap2Bytes
	 */
	private byte[] Bitmap2Bytes(Bitmap bm) {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		bm.compress(Bitmap.CompressFormat.PNG, 100, baos);
		return baos.toByteArray();
	}

	/**
	 * @param
	 * @param bitmap 对象
	 * @param w 要缩放的宽度
	 * @param h 要缩放的高度
	 * @return newBmp 新 Bitmap对象
	 */
	public static Bitmap zoomBitmap(Bitmap bitmap, int w, int h){
		int width = bitmap.getWidth();
		int height = bitmap.getHeight();
		Matrix matrix = new Matrix();
		float scaleWidth = ((float) w / width);
		float scaleHeight = ((float) h / height);
		matrix.postScale(scaleWidth, scaleHeight);
		Bitmap newBmp = Bitmap.createBitmap(bitmap, 0, 0, width, height,
				matrix, true);
		return newBmp;
	}

	// 复制文件
	private void copyfile(String path,String picturename) {
		File file = new File(path);
		if (!file.exists()) {
			InputStream inputStream = null;
			FileOutputStream fos = null;
			byte[] tmp = new byte[1024];
			try {
				inputStream = getApplicationContext().getAssets().open(picturename);
				fos = new FileOutputStream(file);

				while (inputStream.read(tmp) > 0) {
					fos.write(tmp);
				}
				fos.flush();

			} catch (IOException e) {
				e.printStackTrace();
			} finally {

				try {
					if(fos!=null || null!=inputStream) {
						inputStream.close();
						//fos.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
